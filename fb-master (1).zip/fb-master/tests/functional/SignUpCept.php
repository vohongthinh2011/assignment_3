<?php 
$I = new FunctionalTester($scenario);
$I->wantTo('perform actions and see result');
